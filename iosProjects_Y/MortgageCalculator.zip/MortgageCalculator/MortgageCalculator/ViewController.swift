//
//  ViewController.swift
//  MortgageCalculator
//
//  Created by mac07 on 6/5/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

