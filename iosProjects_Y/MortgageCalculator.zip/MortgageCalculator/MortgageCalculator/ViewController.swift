//
//  ViewController.swift
//  MortgageCalculator
//
//  Created by mac07 on 6/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var mortgageCalc: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        mortgageCalc.text = "Mortgage Caclulator"
        // Do any additional setup after loading the view.
    }


}

